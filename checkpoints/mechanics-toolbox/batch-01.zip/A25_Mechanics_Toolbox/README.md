# A25 Mechanics Toolbox

A browser-native JavaScript mechanics toolbox for static websites and Android WebView hosts. Node.js is used only for development tests. The package has no runtime dependencies, server requirement, or bundling requirement.

This is working code, not the A25 Mechanics Library research archive.

## Test

```sh
npm test
```

## Import

```js
import { createCommand, createSeededRng } from './src/index.js';

const rng = createSeededRng(42);
const command = createCommand({
  commandId: 'cmd-000001',
  type: 'resource.gather',
  actorId: 'actor-1',
  roomId: 'wild',
  issuedAt: 0,
  payload: { itemId: 'wood' },
  expectedRevision: 0,
});
```
